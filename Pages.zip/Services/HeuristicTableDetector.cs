using MVCapplication.Models;

namespace MVCapplication.Services;

public sealed class HeuristicTableDetector : ITableDetector
{
    public IReadOnlyList<TableBlock> Detect(PdfPageModel page, IReadOnlyList<PdfTextRun> runs, IReadOnlyList<PdfPathSegment> paths)
    {
        var ruled = DetectRuled(runs, paths);
        var borderless = DetectBorderless(runs)
            .Where(candidate => ruled.All(table => !Overlaps(candidate, table)))
            .ToList();
        return ruled.Concat(borderless).OrderByDescending(table => table.Y + table.Height).ThenBy(table => table.X).ToList();
    }

    private static bool Overlaps(TableBlock first, TableBlock second) =>
        first.X < second.X + second.Width && first.X + first.Width > second.X
        && first.Y < second.Y + second.Height && first.Y + first.Height > second.Y;

    private static IReadOnlyList<TableBlock> DetectRuled(IReadOnlyList<PdfTextRun> runs, IReadOnlyList<PdfPathSegment> paths)
    {
        const double tolerance = 2;
        var horizontal = MergeAxisRules(paths, horizontal: true, tolerance)
            .Where(rule => rule.End - rule.Start >= 24)
            .ToList();
        var vertical = MergeAxisRules(paths, horizontal: false, tolerance)
            .Where(rule => rule.End - rule.Start >= 12)
            .ToList();
        if (horizontal.Count < 3 || vertical.Count < 3)
        {
            return [];
        }

        var components = GroupRuleComponents(horizontal, vertical, tolerance);
        var tables = components.Select(component => CreateRuledTable(component.Horizontal, component.Vertical, runs, tolerance))
            .Where(table => table is not null)
            .Cast<TableBlock>()
            .OrderByDescending(table => table.Y + table.Height)
            .ThenBy(table => table.X)
            .ToList();
        return tables;
    }

    private static List<AxisRule> MergeAxisRules(IReadOnlyList<PdfPathSegment> paths, bool horizontal, double tolerance)
    {
        var segments = paths.Select(path => horizontal
                ? (Position: (path.Y1 + path.Y2) / 2, Start: Math.Min(path.X1, path.X2), End: Math.Max(path.X1, path.X2), Length: Math.Abs(path.X2 - path.X1), Drift: Math.Abs(path.Y2 - path.Y1))
                : (Position: (path.X1 + path.X2) / 2, Start: Math.Min(path.Y1, path.Y2), End: Math.Max(path.Y1, path.Y2), Length: Math.Abs(path.Y2 - path.Y1), Drift: Math.Abs(path.X2 - path.X1)))
            .Where(segment => segment.Drift <= tolerance && segment.Length > tolerance)
            .ToArray();
        var positions = Unique(segments.Select(segment => segment.Position), tolerance);
        var rules = new List<AxisRule>();

        foreach (var position in positions)
        {
            var intervals = segments.Where(segment => Math.Abs(segment.Position - position) <= tolerance)
                .Select(segment => (segment.Start, segment.End))
                .OrderBy(interval => interval.Start)
                .ToArray();
            if (intervals.Length == 0)
            {
                continue;
            }

            var start = intervals[0].Start;
            var end = intervals[0].End;
            for (var index = 1; index < intervals.Length; index++)
            {
                if (intervals[index].Start <= end + tolerance)
                {
                    end = Math.Max(end, intervals[index].End);
                    continue;
                }

                rules.Add(new AxisRule(position, start, end));
                start = intervals[index].Start;
                end = intervals[index].End;
            }

            rules.Add(new AxisRule(position, start, end));
        }

        return rules;
    }

    private static List<RuleComponent> GroupRuleComponents(
        IReadOnlyList<AxisRule> horizontal,
        IReadOnlyList<AxisRule> vertical,
        double tolerance)
    {
        var parent = Enumerable.Range(0, horizontal.Count + vertical.Count).ToArray();
        var rank = new byte[parent.Length];

        int Find(int item)
        {
            while (parent[item] != item)
            {
                parent[item] = parent[parent[item]];
                item = parent[item];
            }

            return item;
        }

        void Union(int first, int second)
        {
            var firstRoot = Find(first);
            var secondRoot = Find(second);
            if (firstRoot == secondRoot)
            {
                return;
            }

            if (rank[firstRoot] < rank[secondRoot])
            {
                parent[firstRoot] = secondRoot;
            }
            else
            {
                parent[secondRoot] = firstRoot;
                if (rank[firstRoot] == rank[secondRoot])
                {
                    rank[firstRoot]++;
                }
            }
        }

        for (var horizontalIndex = 0; horizontalIndex < horizontal.Count; horizontalIndex++)
        {
            var row = horizontal[horizontalIndex];
            for (var verticalIndex = 0; verticalIndex < vertical.Count; verticalIndex++)
            {
                var column = vertical[verticalIndex];
                if (column.Position >= row.Start - tolerance && column.Position <= row.End + tolerance
                    && row.Position >= column.Start - tolerance && row.Position <= column.End + tolerance)
                {
                    Union(horizontalIndex, horizontal.Count + verticalIndex);
                }
            }
        }

        return Enumerable.Range(0, parent.Length)
            .GroupBy(Find)
            .Select(group => new RuleComponent(
                group.Where(index => index < horizontal.Count).Select(index => horizontal[index]).ToList(),
                group.Where(index => index >= horizontal.Count).Select(index => vertical[index - horizontal.Count]).ToList()))
            .Where(component => component.Horizontal.Count >= 3 && component.Vertical.Count >= 3)
            .ToList();
    }

    private static TableBlock? CreateRuledTable(
        IReadOnlyList<AxisRule> horizontal,
        IReadOnlyList<AxisRule> vertical,
        IReadOnlyList<PdfTextRun> runs,
        double tolerance)
    {
        var xBounds = Unique(vertical.Select(rule => rule.Position), tolerance);
        var yBounds = Unique(horizontal.Select(rule => rule.Position), tolerance).OrderByDescending(value => value).ToList();
        if (xBounds.Count < 3 || yBounds.Count < 3)
        {
            return null;
        }

        while (xBounds.Count > 3 && !HasTextWithin(runs, xBounds[0], xBounds[1], yBounds[^1], yBounds[0]))
        {
            xBounds.RemoveAt(0);
        }
        while (xBounds.Count > 3 && !HasTextWithin(runs, xBounds[^2], xBounds[^1], yBounds[^1], yBounds[0]))
        {
            xBounds.RemoveAt(xBounds.Count - 1);
        }
        while (yBounds.Count > 3 && !HasTextWithin(runs, xBounds[0], xBounds[^1], yBounds[1], yBounds[0]))
        {
            yBounds.RemoveAt(0);
        }
        while (yBounds.Count > 3 && !HasTextWithin(runs, xBounds[0], xBounds[^1], yBounds[^1], yBounds[^2]))
        {
            yBounds.RemoveAt(yBounds.Count - 1);
        }
        if (xBounds[^1] - xBounds[0] < 40 || yBounds[0] - yBounds[^1] < 24)
        {
            return null;
        }

        var rowCount = yBounds.Count - 1;
        var columnCount = xBounds.Count - 1;
        var occupied = new bool[rowCount, columnCount];
        var table = new TableBlock
        {
            DetectionMethod = "iText ruled-line geometry",
            X = xBounds[0],
            Y = yBounds[^1],
            Width = xBounds[^1] - xBounds[0],
            Height = yBounds[0] - yBounds[^1],
            ColumnCount = columnCount,
            ColumnPositions = xBounds.ToList()
        };
        var rowRuns = new List<List<List<PdfTextRun>>>();

        for (var rowIndex = 0; rowIndex < rowCount; rowIndex++)
        {
            var cells = new List<TableCell>();
            var cellsRuns = new List<List<PdfTextRun>>();
            for (var columnIndex = 0; columnIndex < columnCount; columnIndex++)
            {
                if (occupied[rowIndex, columnIndex])
                {
                    continue;
                }

                var columnSpan = 1;
                while (columnIndex + columnSpan < columnCount
                    && !HasVerticalBoundary(vertical, xBounds[columnIndex + columnSpan], yBounds[rowIndex + 1], yBounds[rowIndex], tolerance))
                {
                    columnSpan++;
                }

                var rowSpan = 1;
                while (rowIndex + rowSpan < rowCount
                    && !HasHorizontalBoundary(horizontal, yBounds[rowIndex + rowSpan], xBounds[columnIndex], xBounds[columnIndex + columnSpan], tolerance)
                    && !HasInternalVerticalBoundary(vertical, xBounds, columnIndex, columnSpan,
                        yBounds[rowIndex + rowSpan + 1], yBounds[rowIndex + rowSpan], tolerance))
                {
                    rowSpan++;
                }

                for (var mergedRow = rowIndex; mergedRow < rowIndex + rowSpan; mergedRow++)
                {
                    for (var mergedColumn = columnIndex; mergedColumn < columnIndex + columnSpan; mergedColumn++)
                    {
                        occupied[mergedRow, mergedColumn] = true;
                    }
                }

                var left = xBounds[columnIndex];
                var right = xBounds[columnIndex + columnSpan];
                var top = yBounds[rowIndex];
                var bottom = yBounds[rowIndex + rowSpan];
                var cellRuns = runs.Where(run =>
                {
                    var centerX = run.X + run.Width / 2;
                    var centerY = run.Y - run.Height / 2;
                    var insideHorizontalRange = centerX >= left - tolerance
                        && (columnIndex + columnSpan == columnCount
                            ? centerX <= right + tolerance
                            : centerX < right - tolerance);
                    var insideVerticalRange = centerY >= bottom - tolerance
                        && (rowIndex == 0 ? centerY <= top + tolerance : centerY < top - tolerance);
                    return insideHorizontalRange && insideVerticalRange;
                }).ToList();
                var cellText = JoinCellLines(cellRuns);
                cells.Add(new TableCell
                {
                    Text = cellText,
                    ColumnIndex = columnIndex,
                    ColumnSpan = columnSpan,
                    RowSpan = rowSpan,
                    HorizontalAlignment = InferAlignment(cellRuns, left, right)
                });
                cellsRuns.Add(cellRuns);
            }

            table.Rows.Add(cells);
            rowRuns.Add(cellsRuns);
        }

        if (table.Rows.Count(row => row.Any(cell => !string.IsNullOrWhiteSpace(cell.Text))) < 2)
        {
            return null;
        }

        SetHeader(table, rowRuns);
        table.Text = BuildTableText(table);
        return table;
    }

    private static bool HasTextWithin(IReadOnlyList<PdfTextRun> runs, double left, double right, double bottom, double top) =>
        runs.Any(run => run.X + run.Width / 2 >= left && run.X + run.Width / 2 <= right
            && run.Y - run.Height / 2 >= bottom && run.Y - run.Height / 2 <= top);

    private static bool HasVerticalBoundary(IReadOnlyList<AxisRule> rules, double x, double lower, double upper, double tolerance) =>
        rules.Any(rule => Math.Abs(rule.Position - x) <= tolerance
            && rule.Start <= lower + tolerance && rule.End >= upper - tolerance);

    private static bool HasHorizontalBoundary(IReadOnlyList<AxisRule> rules, double y, double left, double right, double tolerance) =>
        rules.Any(rule => Math.Abs(rule.Position - y) <= tolerance
            && rule.Start <= left + tolerance && rule.End >= right - tolerance);

    private static bool HasInternalVerticalBoundary(
        IReadOnlyList<AxisRule> rules,
        IReadOnlyList<double> xBounds,
        int columnIndex,
        int columnSpan,
        double lower,
        double upper,
        double tolerance)
    {
        for (var boundary = columnIndex + 1; boundary < columnIndex + columnSpan; boundary++)
        {
            if (HasVerticalBoundary(rules, xBounds[boundary], lower, upper, tolerance))
            {
                return true;
            }
        }

        return false;
    }

    private static string JoinCellLines(IReadOnlyList<PdfTextRun> runs)
    {
        if (runs.Count == 0)
        {
            return string.Empty;
        }

        return string.Join(Environment.NewLine, GroupLines(runs)
            .Select(line => line.Text)
            .Where(text => !string.IsNullOrWhiteSpace(text)));
    }

    private static string InferAlignment(IReadOnlyList<PdfTextRun> runs, double left, double right)
    {
        if (runs.Count == 0)
        {
            return "left";
        }

        var textLeft = runs.Min(run => run.X);
        var textRight = runs.Max(run => run.X + run.Width);
        var cellWidth = right - left;
        if (cellWidth <= 0)
        {
            return "left";
        }

        if (Math.Abs((textLeft + textRight) / 2 - (left + right) / 2) <= cellWidth * 0.12)
        {
            return "center";
        }

        return right - textRight < cellWidth * 0.12 && textLeft - left >= cellWidth * 0.12 ? "right" : "left";
    }

    private static string BuildTableText(TableBlock table) => string.Join(Environment.NewLine,
        table.Rows.Select(row =>
        {
            var columns = Enumerable.Repeat(string.Empty, table.ColumnCount).ToArray();
            foreach (var cell in row)
            {
                if (cell.ColumnIndex < columns.Length)
                {
                    columns[cell.ColumnIndex] = cell.Text;
                }
            }

            return string.Join("\t", columns);
        }));

    private sealed record AxisRule(double Position, double Start, double End);
    private sealed record RuleComponent(List<AxisRule> Horizontal, List<AxisRule> Vertical);

    private static IReadOnlyList<TableBlock> DetectBorderless(IReadOnlyList<PdfTextRun> runs)
    {
        var candidates = GroupLines(runs)
            .Select(line => (Line: line, Cells: SplitIntoCells(line)))
            .Where(row => row.Cells.Count >= 2)
            .ToList();
        if (candidates.Count < 2)
        {
            return [];
        }

        var groups = new List<List<(PdfTextLine Line, List<List<PdfTextRun>> Cells)>>();
        foreach (var candidate in candidates)
        {
            if (groups.Count == 0)
            {
                groups.Add([candidate]);
                continue;
            }

            var previous = groups[^1][^1].Line;
            var verticalGap = previous.Y - candidate.Line.Y;
            var rowHeight = Math.Max(previous.Height, candidate.Line.Height);
            if (verticalGap > Math.Max(16, rowHeight * 2.8))
            {
                groups.Add([candidate]);
            }
            else
            {
                groups[^1].Add(candidate);
            }
        }

        var tables = new List<TableBlock>();
        foreach (var group in groups.Where(group => group.Count >= 2))
        {
            var columns = new List<(double X, HashSet<int> Rows)>();
            for (var rowIndex = 0; rowIndex < group.Count; rowIndex++)
            {
                foreach (var cell in group[rowIndex].Cells)
                {
                    var x = cell[0].X;
                    var columnIndex = columns.FindIndex(column => Math.Abs(column.X - x) <= 16);
                    if (columnIndex < 0)
                    {
                        columns.Add((x, [rowIndex]));
                    }
                    else
                    {
                        columns[columnIndex].Rows.Add(rowIndex);
                    }
                }
            }

            var stableColumns = columns.Where(column => column.Rows.Count >= 2)
                .OrderBy(column => column.X).Select(column => column.X).ToArray();
            if (stableColumns.Length < 2)
            {
                continue;
            }

            var rowRuns = new List<List<List<PdfTextRun>>>();
            var includedLines = new List<PdfTextLine>();
            foreach (var candidate in group)
            {
                var cells = Enumerable.Range(0, stableColumns.Length).Select(_ => new List<PdfTextRun>()).ToArray();
                foreach (var segment in candidate.Cells)
                {
                    var nearestColumn = Enumerable.Range(0, stableColumns.Length)
                        .MinBy(index => Math.Abs(stableColumns[index] - segment[0].X));
                    cells[nearestColumn].AddRange(segment);
                }

                rowRuns.Add(cells.Select(cell => cell.OrderBy(run => run.X).ToList()).ToList());
                includedLines.Add(candidate.Line);
            }

            var groupTop = group[0].Line.Y;
            var groupBottom = group[^1].Line.Y;
            var tableLeft = group.Min(candidate => candidate.Line.X);
            var tableRight = group.Max(candidate => candidate.Line.X + candidate.Line.Width);
            var continuationLines = GroupLines(runs)
                .Where(line => SplitIntoCells(line).Count == 1
                    && line.Y <= groupTop && line.Y >= groupBottom
                    && line.X >= tableLeft - line.AverageFontSize
                    && line.X + line.Width <= tableRight + line.AverageFontSize)
                .ToList();

            foreach (var continuationLine in continuationLines)
            {
                var rowIndex = Enumerable.Range(0, group.Count)
                    .MinBy(index => Math.Abs(group[index].Line.Y - continuationLine.Y));
                if (Math.Abs(group[rowIndex].Line.Y - continuationLine.Y)
                    > Math.Max(8, continuationLine.AverageFontSize * 1.5))
                {
                    continue;
                }

                var segment = SplitIntoCells(continuationLine)[0];
                var columnIndex = Enumerable.Range(0, stableColumns.Length)
                    .MinBy(index => Math.Abs(stableColumns[index] - segment[0].X));
                rowRuns[rowIndex][columnIndex].AddRange(segment);
                includedLines.Add(continuationLine);
            }

            var tableRows = new List<List<TableCell>>();
            foreach (var orderedCells in rowRuns)
            {
                var row = orderedCells.Select((cell, index) => new TableCell
                {
                    Text = JoinCellLines(cell),
                    ColumnIndex = index,
                    HorizontalAlignment = InferAlignment(cell, stableColumns[index],
                        index + 1 < stableColumns.Length ? stableColumns[index + 1] : tableRight)
                }).ToList();
                tableRows.Add(row);
            }

            if (tableRows.Count < 2)
            {
                continue;
            }

            var minX = includedLines.Min(line => line.X);
            var maxX = includedLines.Max(line => line.X + line.Width);
            var top = includedLines.Max(line => line.Y);
            var bottom = includedLines.Min(line => line.Y - line.Height);
            var table = new TableBlock
            {
                DetectionMethod = "aligned-columns",
                X = minX,
                Y = bottom,
                Width = maxX - minX,
                Height = top - bottom,
                ColumnCount = stableColumns.Length,
                ColumnPositions = BuildColumnBoundaries(stableColumns, minX, maxX),
                Rows = tableRows
            };
            SetHeader(table, rowRuns);
            table.Text = BuildTableText(table);
            tables.Add(table);
        }

        return tables;
    }

    private static List<double> BuildColumnBoundaries(IReadOnlyList<double> columnStarts, double left, double right)
    {
        var boundaries = new List<double> { left };
        for (var index = 1; index < columnStarts.Count; index++)
        {
            boundaries.Add((columnStarts[index - 1] + columnStarts[index]) / 2);
        }

        boundaries.Add(Math.Max(boundaries[^1], right));
        return boundaries;
    }

    private static List<List<PdfTextRun>> SplitIntoCells(PdfTextLine line)
    {
        var cells = new List<List<PdfTextRun>>();
        List<PdfTextRun>? currentCell = null;
        PdfTextRun? previous = null;
        foreach (var run in line.Runs.OrderBy(run => run.X))
        {
            if (string.IsNullOrWhiteSpace(run.Text))
            {
                continue;
            }

            var gap = previous is null ? 0 : run.X - (previous.X + previous.Width);
            var gapThreshold = Math.Max(9, Math.Max(run.FontSize, previous?.FontSize ?? 0) * 0.9);
            if (currentCell is null || gap > gapThreshold)
            {
                currentCell = [];
                cells.Add(currentCell);
            }

            currentCell.Add(run);
            previous = run;
        }

        return cells;
    }

    private static void SetHeader(TableBlock table, IReadOnlyList<List<List<PdfTextRun>>> rowRuns)
    {
        var firstRow = table.Rows[0];
        var recognizedLabels = new[] { "course", "institute", "institution", "year", "result", "degree", "school", "date", "company", "position", "description", "quantity", "price", "total" };
        var labelCount = firstRow.Count(cell => recognizedLabels.Any(label =>
            cell.Text.Contains(label, StringComparison.OrdinalIgnoreCase)));
        var cellsWithText = firstRow.Select((cell, index) => (cell, index))
            .Where(item => !string.IsNullOrWhiteSpace(item.cell.Text)).ToArray();
        var boldCells = cellsWithText.Count(item => rowRuns[0][item.index].Any(run => run.Bold));
        if (labelCount < 2 && (cellsWithText.Length == 0 || boldCells < Math.Ceiling(cellsWithText.Length * 0.6)))
        {
            return;
        }

        table.HeaderRowCount = 1;
        foreach (var cell in firstRow)
        {
            cell.IsHeader = true;
        }
    }

    internal static List<PdfTextLine> GroupLines(IReadOnlyList<PdfTextRun> runs)
    {
        var lines = new List<List<PdfTextRun>>();
        foreach (var run in runs.OrderByDescending(run => run.Y).ThenBy(run => run.X))
        {
            var line = lines.FirstOrDefault(candidate => Math.Abs(candidate[0].Y - run.Y) <= Math.Max(2, run.FontSize * 0.35));
            if (line is null)
            {
                line = [];
                lines.Add(line);
            }

            line.Add(run);
        }

        return lines.Select(group =>
        {
            var ordered = group.OrderBy(run => run.X).ToList();
            var text = JoinRuns(ordered);
            return new PdfTextLine
            {
                Runs = ordered,
                Text = text,
                X = ordered.Min(run => run.X),
                Y = ordered.Average(run => run.Y),
                Width = ordered.Max(run => run.X + run.Width) - ordered.Min(run => run.X),
                Height = ordered.Max(run => run.Height)
            };
        }).OrderByDescending(line => line.Y).ToList();
    }

    internal static string JoinRuns(IEnumerable<PdfTextRun> runs)
    {
        var ordered = runs.OrderBy(run => run.X).ToArray();
        var result = new System.Text.StringBuilder();
        PdfTextRun? previous = null;
        foreach (var run in ordered)
        {
            if (previous is not null && result.Length > 0 && !char.IsWhiteSpace(result[^1])
                && !string.IsNullOrWhiteSpace(run.Text) && !char.IsWhiteSpace(run.Text[0]))
            {
                var gap = run.X - (previous.X + previous.Width);
                var measuredSpaceWidth = new[] { previous.SpaceWidth, run.SpaceWidth }
                    .Where(width => width > 0)
                    .DefaultIfEmpty(Math.Min(previous.FontSize, run.FontSize) * 0.5)
                    .Min();
                if (gap > Math.Max(0.5, measuredSpaceWidth * 0.5))
                {
                    result.Append(' ');
                }
            }

            result.Append(run.Text);
            previous = run;
        }

        return result.ToString().Trim();
    }

    private static List<double> Unique(IEnumerable<double> values, double tolerance)
    {
        var result = new List<double>();
        foreach (var value in values.OrderBy(value => value))
        {
            if (result.Count == 0 || Math.Abs(result[^1] - value) > tolerance)
            {
                result.Add(value);
            }
            else
            {
                result[^1] = (result[^1] + value) / 2;
            }
        }

        return result;
    }
}
