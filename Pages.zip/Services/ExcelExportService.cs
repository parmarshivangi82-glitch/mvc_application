using ClosedXML.Excel;
using MVCapplication.Models;

namespace MVCapplication.Services;

public sealed class ExcelExportService : IExcelExportService
{
    public byte[] Export(ExtractedDocument document)
    {
        using var workbook = new XLWorkbook();
        var content = workbook.Worksheets.Add("Content");
        content.Cell(1, 1).Value = "Page";
        content.Cell(1, 2).Value = "Block type";
        content.Cell(1, 3).Value = "X (pt)";
        content.Cell(1, 4).Value = "Y (pt)";
        content.Cell(1, 5).Value = "Text";
        var contentRow = 2;

        var tables = workbook.Worksheets.Add("Table cells");
        tables.Cell(1, 1).Value = "Page";
        tables.Cell(1, 2).Value = "Table";
        tables.Cell(1, 3).Value = "Row";
        tables.Cell(1, 4).Value = "Column";
        tables.Cell(1, 5).Value = "Cell";
        tables.Cell(1, 6).Value = "Row span";
        tables.Cell(1, 7).Value = "Column span";
        var tableRow = 2;

        foreach (var page in document.Pages.OrderBy(page => page.Number))
        {
            var tableIndex = 0;
            foreach (var block in page.Blocks)
            {
                content.Cell(contentRow, 1).Value = page.Number;
                content.Cell(contentRow, 2).Value = block switch
                {
                    HeadingBlock => "Heading",
                    TableBlock => "Table",
                    ListBlock => "List",
                    _ => "Paragraph"
                };
                content.Cell(contentRow, 3).Value = block.X;
                content.Cell(contentRow, 4).Value = block.Y;
                content.Cell(contentRow, 5).Value = block.Text;
                contentRow++;

                if (block is not TableBlock table)
                {
                    continue;
                }

                tableIndex++;
                var tableNumber = table.TableGroupId > 0 ? table.TableGroupId : tableIndex;
                for (var rowIndex = 0; rowIndex < table.Rows.Count; rowIndex++)
                {
                    for (var cellIndex = 0; cellIndex < table.Rows[rowIndex].Count; cellIndex++)
                    {
                        var cell = table.Rows[rowIndex][cellIndex];
                        tables.Cell(tableRow, 1).Value = page.Number;
                        tables.Cell(tableRow, 2).Value = tableNumber;
                        tables.Cell(tableRow, 3).Value = rowIndex + 1;
                        tables.Cell(tableRow, 4).Value = table.ColumnCount > 0 ? cell.ColumnIndex + 1 : cellIndex + 1;
                        tables.Cell(tableRow, 5).Value = cell.Text;
                        tables.Cell(tableRow, 6).Value = cell.RowSpan;
                        tables.Cell(tableRow, 7).Value = cell.ColumnSpan;
                        tableRow++;
                    }
                }
            }
        }

        foreach (var sheet in workbook.Worksheets)
        {
            var header = sheet.Row(1);
            header.Style.Font.Bold = true;
            header.Style.Font.FontColor = XLColor.White;
            header.Style.Fill.BackgroundColor = XLColor.FromHtml("#17324D");
            sheet.SheetView.FreezeRows(1);
            sheet.Columns().AdjustToContents(1, 60);
            sheet.Column(sheet.LastColumnUsed()?.ColumnNumber() ?? 1).Width = Math.Min(60, Math.Max(14, sheet.Column(sheet.LastColumnUsed()?.ColumnNumber() ?? 1).Width));
        }

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }
}
