using System.Text.Json;
using MVCapplication.Models;

namespace MVCapplication.Services;

public static class PdfDocumentSerializer
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

    public static string Serialize(ExtractedDocument document) => JsonSerializer.Serialize(document, Options);

    public static ExtractedDocument DeserializeOrLegacy(string storedValue, string fileName)
    {
        try
        {
            var document = JsonSerializer.Deserialize<ExtractedDocument>(storedValue);
            if (document is not null && document.Pages is not null)
            {
                document.FileName = fileName;
                return document;
            }
        }
        catch (JsonException)
        {
        }

        var legacy = new ExtractedDocument { FileName = fileName };
        if (!string.IsNullOrWhiteSpace(storedValue))
        {
            var page = new PdfPageModel { Number = 1 };
            page.Blocks.Add(new ParagraphBlock { Text = storedValue });
            legacy.Pages.Add(page);
            legacy.Metadata.PageCount = 1;
        }

        return legacy;
    }

    public static string ToPlainText(ExtractedDocument document)
    {
        var lines = new List<string>();
        foreach (var page in document.Pages.OrderBy(page => page.Number))
        {
            if (lines.Count > 0)
            {
                lines.Add(string.Empty);
            }

            foreach (var block in page.Blocks)
            {
                switch (block)
                {
                    case TableBlock table:
                        lines.AddRange(table.Rows.Select(row => FormatTableRow(table, row)));
                        break;
                    case ListBlock list:
                        lines.AddRange(list.Items.Select((item, index) => $"{(list.Ordered ? $"{index + 1}." : "•")} {item.Text}"));
                        break;
                    default:
                        lines.Add(block.Text);
                        break;
                }
            }
        }

        return string.Join(Environment.NewLine, lines);
    }

    private static string FormatTableRow(TableBlock table, IReadOnlyList<TableCell> row)
    {
        if (table.ColumnCount <= 0)
        {
            return string.Join("\t", row.Select(cell => cell.Text));
        }

        var columns = Enumerable.Repeat(string.Empty, table.ColumnCount).ToArray();
        for (var index = 0; index < row.Count; index++)
        {
            var cell = row[index];
            var column = cell.ColumnIndex;
            if (row.All(item => item.ColumnIndex == 0))
            {
                column = index;
            }

            if (column >= 0 && column < columns.Length)
            {
                columns[column] = cell.Text;
            }
        }

        return string.Join("\t", columns);
    }
}
