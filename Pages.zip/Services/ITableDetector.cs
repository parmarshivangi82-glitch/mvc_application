using MVCapplication.Models;

namespace MVCapplication.Services;

public interface ITableDetector
{
    IReadOnlyList<TableBlock> Detect(PdfPageModel page, IReadOnlyList<PdfTextRun> runs, IReadOnlyList<PdfPathSegment> paths);
}
