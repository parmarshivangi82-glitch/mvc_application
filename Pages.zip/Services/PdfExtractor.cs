using System.Text.RegularExpressions;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Data;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using MVCapplication.Models;

namespace MVCapplication.Services;

public sealed class PdfExtractor(ITableDetector tableDetector) : IPdfExtractor
{
    private static readonly Regex ListMarker = new(@"^\s*(?<marker>[-*•]|\d+[.)])\s+", RegexOptions.Compiled);

    public ExtractedDocument Extract(Stream pdfStream, string fileName, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(pdfStream);
        if (!pdfStream.CanRead)
        {
            throw new ArgumentException("The PDF stream must be readable.", nameof(pdfStream));
        }

        using var pdf = new PdfDocument(new PdfReader(pdfStream));
        var info = pdf.GetDocumentInfo();
        var pageCount = pdf.GetNumberOfPages();
        var result = new ExtractedDocument
        {
            FileName = System.IO.Path.GetFileName(fileName),
            Metadata = new PdfMetadata
            {
                Title = info.GetTitle(),
                Author = info.GetAuthor(),
                Subject = info.GetSubject(),
                PageCount = pageCount
            }
        };

        for (var pageNumber = 1; pageNumber <= pageCount; pageNumber++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var pdfPage = pdf.GetPage(pageNumber);
            var listener = new PositionedTextListener();
            new PdfCanvasProcessor(listener).ProcessPageContent(pdfPage);

            var pageSize = pdfPage.GetPageSize();
            var page = new PdfPageModel
            {
                Number = pageNumber,
                Width = pageSize.GetWidth(),
                Height = pageSize.GetHeight(),
                RequiresOcr = listener.HasImage && listener.Runs.Count == 0
            };
            var textRuns = listener.Runs;
            var tables = tableDetector.Detect(page, textRuns, listener.Paths);
            var textBlocks = BuildTextBlocks(textRuns, tables, page.Width);
            page.Blocks = OrderPageBlocks(tables.Cast<PdfBlock>().Concat(textBlocks), page.Width);
            result.Pages.Add(page);
        }

        LinkContinuedTables(result.Pages);
        return result;
    }

    private static void LinkContinuedTables(IReadOnlyList<PdfPageModel> pages)
    {
        var nextGroupId = 1;
        foreach (var table in pages.SelectMany(page => page.Blocks.OfType<TableBlock>()))
        {
            table.TableGroupId = nextGroupId++;
        }

        for (var pageIndex = 1; pageIndex < pages.Count; pageIndex++)
        {
            var previousPage = pages[pageIndex - 1];
            var currentPage = pages[pageIndex];
            var previousTables = previousPage.Blocks.OfType<TableBlock>()
                .Where(table => table.Y <= previousPage.Height * 0.18)
                .OrderBy(table => table.X)
                .ToList();
            var currentTables = currentPage.Blocks.OfType<TableBlock>()
                .Where(table => currentPage.Height - (table.Y + table.Height) <= currentPage.Height * 0.18)
                .OrderBy(table => table.X)
                .ToList();

            foreach (var currentTable in currentTables)
            {
                var previousTable = previousTables
                    .Where(table => table.TableGroupId != 0 && AreContinuationCandidates(
                        table, previousPage, currentTable, currentPage))
                    .OrderBy(table => Math.Abs(table.X / previousPage.Width - currentTable.X / currentPage.Width))
                    .FirstOrDefault();
                if (previousTable is null)
                {
                    continue;
                }

                currentTable.TableGroupId = previousTable.TableGroupId;
                currentTable.ContinuesFromPreviousPage = true;
                previousTable.ContinuesOnNextPage = true;
                previousTables.Remove(previousTable);
            }
        }
    }

    private static bool AreContinuationCandidates(
        TableBlock previous,
        PdfPageModel previousPage,
        TableBlock current,
        PdfPageModel currentPage)
    {
        if (previous.ColumnCount < 2 || previous.ColumnCount != current.ColumnCount
            || previous.ColumnPositions.Count != current.ColumnPositions.Count
            || previousPage.Width <= 0 || currentPage.Width <= 0)
        {
            return false;
        }

        if (Math.Abs(previous.X / previousPage.Width - current.X / currentPage.Width) > 0.08
            || Math.Abs(previous.Width / previousPage.Width - current.Width / currentPage.Width) > 0.12)
        {
            return false;
        }

        var previousSpan = previous.ColumnPositions[^1] - previous.ColumnPositions[0];
        var currentSpan = current.ColumnPositions[^1] - current.ColumnPositions[0];
        if (previousSpan <= 0 || currentSpan <= 0)
        {
            return false;
        }

        for (var index = 1; index < previous.ColumnPositions.Count - 1; index++)
        {
            var previousPosition = (previous.ColumnPositions[index] - previous.ColumnPositions[0]) / previousSpan;
            var currentPosition = (current.ColumnPositions[index] - current.ColumnPositions[0]) / currentSpan;
            if (Math.Abs(previousPosition - currentPosition) > 0.08)
            {
                return false;
            }
        }

        return true;
    }

    private static List<PdfBlock> BuildTextBlocks(
        IReadOnlyList<PdfTextRun> runs,
        IReadOnlyList<TableBlock> tables,
        double pageWidth)
    {
        var lines = GetReadingOrderLines(runs, tables, pageWidth);
        var typicalSize = runs.Where(run => run.FontSize > 0)
            .Select(run => run.FontSize)
            .OrderBy(size => size)
            .Skip(Math.Max(0, runs.Count(run => run.FontSize > 0) / 2))
            .FirstOrDefault();
        var blocks = new List<PdfBlock>();
        var paragraphLines = new List<PdfTextLine>();
        var previousParagraphLine = (PdfTextLine?)null;

        void FlushParagraph()
        {
            if (paragraphLines.Count == 0)
            {
                return;
            }

            var paragraphRuns = paragraphLines.SelectMany(line => line.Runs).ToList();
            blocks.Add(new ParagraphBlock
            {
                Text = string.Join(" ", paragraphLines.Select(line => line.Text)),
                Runs = paragraphRuns,
                X = paragraphLines.Min(line => line.X),
                Y = paragraphLines.Min(line => line.Y - line.Height),
                Width = paragraphLines.Max(line => line.X + line.Width) - paragraphLines.Min(line => line.X),
                Height = paragraphLines.Max(line => line.Y) - paragraphLines.Min(line => line.Y - line.Height)
            });
            paragraphLines.Clear();
            previousParagraphLine = null;
        }

        foreach (var line in lines)
        {
            if (tables.Any(table => IsInside(line, table)))
            {
                FlushParagraph();
                continue;
            }

            var marker = ListMarker.Match(line.Text);
            if (marker.Success)
            {
                FlushParagraph();
                var itemText = line.Text[marker.Length..].Trim();
                var orderedList = char.IsDigit(marker.Groups["marker"].Value[0]);
                if (blocks.LastOrDefault() is ListBlock existingList && existingList.Ordered == orderedList
                    && Math.Abs(existingList.X - line.X) <= 12)
                {
                    existingList.Items.Add(new ListItem { Text = itemText, Runs = line.Runs });
                    existingList.Text = string.Join(Environment.NewLine, existingList.Items.Select(item => item.Text));
                    existingList.X = Math.Min(existingList.X, line.X);
                    existingList.Y = Math.Min(existingList.Y, line.Y - line.Height);
                    existingList.Width = Math.Max(existingList.Width, line.X + line.Width - existingList.X);
                    existingList.Height = Math.Max(existingList.Height, existingList.Items.Count * line.Height);
                }
                else
                {
                    blocks.Add(new ListBlock
                    {
                        Ordered = orderedList,
                        Items = [new ListItem { Text = itemText, Runs = line.Runs }],
                        Text = itemText,
                        X = line.X,
                        Y = line.Y - line.Height,
                        Width = line.Width,
                        Height = line.Height
                    });
                }

                continue;
            }

            var averageSize = line.AverageFontSize;
            var isHeading = typicalSize > 0 && (averageSize >= typicalSize * 1.28
                || (line.Runs.Any(run => run.Bold) && averageSize >= typicalSize * 1.08));
            if (isHeading)
            {
                FlushParagraph();
                blocks.Add(new HeadingBlock
                {
                    Text = line.Text,
                    Level = averageSize >= typicalSize * 1.8 ? 1 : averageSize >= typicalSize * 1.45 ? 2 : 3,
                    Runs = line.Runs,
                    X = line.X,
                    Y = line.Y - line.Height,
                    Width = line.Width,
                    Height = line.Height
                });
                continue;
            }

            if (previousParagraphLine is not null
                && (previousParagraphLine.Y - line.Y > Math.Max(5, previousParagraphLine.AverageFontSize * 1.8)
                    || line.Y - previousParagraphLine.Y > Math.Max(5, previousParagraphLine.AverageFontSize * 1.8)))
            {
                FlushParagraph();
            }

            paragraphLines.Add(line);
            previousParagraphLine = line;
        }

        FlushParagraph();
        return blocks;
    }

    private static List<PdfTextLine> GetReadingOrderLines(IReadOnlyList<PdfTextRun> runs, IReadOnlyList<TableBlock> tables, double pageWidth)
    {
        var lines = new List<PdfTextLine>();
        foreach (var line in HeuristicTableDetector.GroupLines(runs))
        {
            if (tables.Any(table => IsInside(line, table)))
            {
                continue;
            }

            var fragment = new List<PdfTextRun>();
            PdfTextRun? previous = null;
            foreach (var run in line.Runs)
            {
                var gap = previous is null ? 0 : run.X - (previous.X + previous.Width);
                if (fragment.Count > 0 && gap > Math.Max(30, run.FontSize * 3))
                {
                    lines.Add(CreateLine(fragment));
                    fragment = [];
                }

                fragment.Add(run);
                previous = run;
            }

            if (fragment.Count > 0)
            {
                lines.Add(CreateLine(fragment));
            }
        }

        return OrderLinesByColumn(lines, pageWidth);
    }

    private static PdfTextLine CreateLine(List<PdfTextRun> runs)
    {
        var ordered = runs.OrderBy(run => run.X).ToList();
        return new PdfTextLine
        {
            Runs = ordered,
            Text = HeuristicTableDetector.JoinRuns(ordered),
            X = ordered.Min(run => run.X),
            Y = ordered.Average(run => run.Y),
            Width = ordered.Max(run => run.X + run.Width) - ordered.Min(run => run.X),
            Height = ordered.Max(run => run.Height)
        };
    }

    private static List<PdfTextLine> OrderLinesByColumn(IReadOnlyList<PdfTextLine> lines, double pageWidth)
    {
        var anchors = GetColumnAnchors(lines.Select(line => (line.X, line.Width)), pageWidth);
        if (anchors is null)
        {
            return lines.OrderByDescending(line => line.Y).ThenBy(line => line.X).ToList();
        }

        var (leftX, rightX) = anchors.Value;
        var spanningLines = lines.Where(line => line.X < rightX && line.X + line.Width > rightX
                && line.Width >= (rightX - leftX) * 0.72)
            .OrderByDescending(line => line.Y)
            .ToList();
        var remaining = lines.Except(spanningLines).ToList();
        var ordered = new List<PdfTextLine>();
        var upperBound = double.PositiveInfinity;

        foreach (var spanningLine in spanningLines)
        {
            var band = remaining.Where(line => line.Y < upperBound && line.Y > spanningLine.Y).ToList();
            ordered.AddRange(OrderColumnBand(band, leftX, rightX));
            ordered.Add(spanningLine);
            remaining.RemoveAll(line => band.Contains(line));
            upperBound = spanningLine.Y;
        }

        ordered.AddRange(OrderColumnBand(remaining, leftX, rightX));
        return ordered;
    }

    private static List<PdfBlock> OrderPageBlocks(IEnumerable<PdfBlock> blocks, double pageWidth)
    {
        var allBlocks = blocks.ToList();
        var anchors = GetColumnAnchors(allBlocks.Select(block => (block.X, block.Width)), pageWidth, minimumCount: 1);
        if (anchors is null)
        {
            return allBlocks.OrderByDescending(block => block.Y + block.Height).ThenBy(block => block.X).ToList();
        }

        var (leftX, rightX) = anchors.Value;
        var spanningBlocks = allBlocks.Where(block => block.X < rightX && block.X + block.Width > rightX
                && block.Width >= (rightX - leftX) * 0.72)
            .OrderByDescending(block => block.Y + block.Height)
            .ToList();
        var remaining = allBlocks.Except(spanningBlocks).ToList();
        var ordered = new List<PdfBlock>();
        var upperBound = double.PositiveInfinity;

        foreach (var spanningBlock in spanningBlocks)
        {
            var band = remaining.Where(block => block.Y + block.Height < upperBound
                && block.Y + block.Height > spanningBlock.Y + spanningBlock.Height).ToList();
            ordered.AddRange(OrderBlockBand(band, leftX, rightX));
            ordered.Add(spanningBlock);
            remaining.RemoveAll(band.Contains);
            upperBound = spanningBlock.Y + spanningBlock.Height;
        }

        ordered.AddRange(OrderBlockBand(remaining, leftX, rightX));
        return ordered;
    }

    private static (double LeftX, double RightX)? GetColumnAnchors(
        IEnumerable<(double X, double Width)> elements,
        double pageWidth,
        int minimumCount = 2)
    {
        var anchors = new List<(double X, int Count)>();
        foreach (var (x, _) in elements.OrderBy(element => element.X))
        {
            var index = anchors.FindIndex(anchor => Math.Abs(anchor.X - x) <= 15);
            if (index < 0)
            {
                anchors.Add((x, 1));
            }
            else
            {
                var anchor = anchors[index];
                anchors[index] = ((anchor.X * anchor.Count + x) / (anchor.Count + 1), anchor.Count + 1);
            }
        }

        var candidates = anchors.Where(anchor => anchor.Count >= minimumCount).OrderBy(anchor => anchor.X).ToList();
        foreach (var left in candidates)
        {
            var right = candidates.FirstOrDefault(anchor => anchor.X - left.X >= Math.Max(60, pageWidth * 0.18));
            if (right.Count >= minimumCount)
            {
                return (left.X, right.X);
            }
        }

        return null;
    }

    private static IEnumerable<PdfTextLine> OrderColumnBand(IEnumerable<PdfTextLine> lines, double leftX, double rightX) =>
        lines.OrderBy(line => Math.Abs(line.X - leftX) <= Math.Abs(line.X - rightX) ? 0 : 1)
            .ThenByDescending(line => line.Y)
            .ThenBy(line => line.X);

    private static IEnumerable<PdfBlock> OrderBlockBand(IEnumerable<PdfBlock> blocks, double leftX, double rightX) =>
        blocks.OrderBy(block => Math.Abs(block.X - leftX) <= Math.Abs(block.X - rightX) ? 0 : 1)
            .ThenByDescending(block => block.Y + block.Height)
            .ThenBy(block => block.X);

    private static bool IsInside(PdfTextLine line, TableBlock table) =>
        line.X >= table.X - 2 && line.X <= table.X + table.Width + 2
        && line.Y >= table.Y - 2 && line.Y - line.Height <= table.Y + table.Height + 2;

    private sealed class PositionedTextListener : IEventListener
    {
        private static readonly Regex BoldFont = new(@"bold|black|demi|heavy", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex ItalicFont = new(@"italic|oblique", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public List<PdfTextRun> Runs { get; } = [];
        public List<PdfPathSegment> Paths { get; } = [];
        public bool HasImage { get; private set; }

        public void EventOccurred(IEventData data, EventType type)
        {
            if (type == EventType.RENDER_IMAGE)
            {
                HasImage = true;
                return;
            }

            if (type == EventType.RENDER_PATH && data is PathRenderInfo pathInfo)
            {
                if ((pathInfo.GetOperation() & PathRenderInfo.STROKE) == 0)
                {
                    return;
                }

                foreach (var subpath in pathInfo.GetPath().GetSubpaths())
                {
                    var points = subpath.GetPiecewiseLinearApproximation();
                    for (var index = 1; index < points.Count; index++)
                    {
                        Paths.Add(new PdfPathSegment
                        {
                            X1 = points[index - 1].GetX(),
                            Y1 = points[index - 1].GetY(),
                            X2 = points[index].GetX(),
                            Y2 = points[index].GetY()
                        });
                    }
                }

                return;
            }

            if (type != EventType.RENDER_TEXT || data is not TextRenderInfo textInfo)
            {
                return;
            }

            AddPositionedWords(textInfo);
        }

        public ICollection<EventType> GetSupportedEvents() => new HashSet<EventType>
        {
            EventType.RENDER_TEXT,
            EventType.RENDER_PATH,
            EventType.RENDER_IMAGE
        };

        private void AddPositionedWords(TextRenderInfo textInfo)
        {
            var fontName = textInfo.GetFont()?.GetFontProgram()?.GetFontNames().GetFontName() ?? string.Empty;
            var color = GetHexColor(textInfo.GetFillColor());
            var word = new System.Text.StringBuilder();
            var wordRuns = new List<PdfTextRun>();
            PdfTextRun? previous = null;
            var pendingSpace = false;

            void FlushWord()
            {
                if (word.Length == 0 || wordRuns.Count == 0)
                {
                    return;
                }

                var first = wordRuns[0];
                Runs.Add(new PdfTextRun
                {
                    Text = word.ToString(),
                    FontName = fontName,
                    FontSize = first.FontSize,
                    SpaceWidth = first.SpaceWidth,
                    Bold = BoldFont.IsMatch(fontName),
                    Italic = ItalicFont.IsMatch(fontName),
                    Color = color,
                    X = wordRuns.Min(run => run.X),
                    Y = wordRuns.Average(run => run.Y),
                    Width = wordRuns.Max(run => run.X + run.Width) - wordRuns.Min(run => run.X),
                    Height = wordRuns.Max(run => run.Height)
                });
                word.Clear();
                wordRuns.Clear();
                previous = null;
            }

            foreach (var character in textInfo.GetCharacterRenderInfos())
            {
                var text = character.GetText();
                if (string.IsNullOrEmpty(text))
                {
                    continue;
                }

                if (text.All(char.IsWhiteSpace))
                {
                    FlushWord();
                    pendingSpace = true;
                    continue;
                }

                if (pendingSpace && word.Length == 0)
                {
                    word.Append(' ');
                    pendingSpace = false;
                }

                var baseline = character.GetBaseline();
                var start = baseline.GetStartPoint();
                var end = baseline.GetEndPoint();
                var ascent = character.GetAscentLine().GetStartPoint();
                var descent = character.GetDescentLine().GetStartPoint();
                var x = Math.Min(start.Get(0), end.Get(0));
                var width = Math.Abs(end.Get(0) - start.Get(0));
                var fontSize = character.GetFontSize();
                var spaceWidth = character.GetSingleSpaceWidth();
                if (previous is not null)
                {
                    var gap = x - (previous.X + previous.Width);
                    var measuredSpaceWidth = new[] { previous.SpaceWidth, spaceWidth }
                        .Where(width => width > 0)
                        .DefaultIfEmpty(Math.Min(previous.FontSize, fontSize) * 0.5)
                        .Min();
                    if (gap > Math.Max(0.5, measuredSpaceWidth * 0.5))
                    {
                        FlushWord();
                    }
                }

                word.Append(text);
                wordRuns.Add(new PdfTextRun
                {
                    Text = text,
                    FontSize = fontSize,
                    SpaceWidth = spaceWidth,
                    X = x,
                    Y = start.Get(1),
                    Width = width,
                    Height = Math.Abs(ascent.Get(1) - descent.Get(1))
                });
                previous = wordRuns[^1];
            }

            FlushWord();
        }

        private static string GetHexColor(iText.Kernel.Colors.Color? color)
        {
            var values = color?.GetColorValue();
            if (values is null || values.Length == 0)
            {
                return "#000000";
            }

            if (values.Length == 1)
            {
                var gray = ToByte(values[0]);
                return $"#{gray:X2}{gray:X2}{gray:X2}";
            }

            var red = values.Length >= 4 ? (1 - values[0]) * (1 - values[3]) : values[0];
            var green = values.Length >= 4 ? (1 - values[1]) * (1 - values[3]) : values[1];
            var blue = values.Length >= 4 ? (1 - values[2]) * (1 - values[3]) : values[2];
            return $"#{ToByte(red):X2}{ToByte(green):X2}{ToByte(blue):X2}";
        }

        private static int ToByte(double value) => (int)Math.Round(Math.Clamp(value, 0, 1) * 255);
    }
}
