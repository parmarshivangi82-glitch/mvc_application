using MVCapplication.Models;

namespace MVCapplication.Services;

public interface IExcelExportService
{
    byte[] Export(ExtractedDocument document);
}
