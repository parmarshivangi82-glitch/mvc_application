using MVCapplication.Models;

namespace MVCapplication.Services;

public interface IPdfExtractor
{
    ExtractedDocument Extract(Stream pdfStream, string fileName, CancellationToken cancellationToken = default);
}
