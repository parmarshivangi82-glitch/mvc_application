using System.Text.Json.Serialization;

namespace MVCapplication.Models;

public sealed class ExtractedDocument
{
    public string FileName { get; set; } = string.Empty;
    public PdfMetadata Metadata { get; set; } = new();
    public List<PdfPageModel> Pages { get; set; } = [];
}

public sealed class PdfMetadata
{
    public string? Title { get; set; }
    public string? Author { get; set; }
    public string? Subject { get; set; }
    public int PageCount { get; set; }
}

public sealed class PdfPageModel
{
    public int Number { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public bool RequiresOcr { get; set; }
    public List<PdfBlock> Blocks { get; set; } = [];
}

[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind")]
[JsonDerivedType(typeof(ParagraphBlock), "paragraph")]
[JsonDerivedType(typeof(HeadingBlock), "heading")]
[JsonDerivedType(typeof(TableBlock), "table")]
[JsonDerivedType(typeof(ListBlock), "list")]
public abstract class PdfBlock
{
    public string Text { get; set; } = string.Empty;
    public double X { get; set; }
    public double Y { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
}

public sealed class ParagraphBlock : PdfBlock
{
    public List<PdfTextRun> Runs { get; set; } = [];
}

public sealed class HeadingBlock : PdfBlock
{
    public int Level { get; set; }
    public List<PdfTextRun> Runs { get; set; } = [];
}

public sealed class TableBlock : PdfBlock
{
    public string DetectionMethod { get; set; } = string.Empty;
    public int HeaderRowCount { get; set; }
    public int ColumnCount { get; set; }
    public List<double> ColumnPositions { get; set; } = [];
    public int TableGroupId { get; set; }
    public bool ContinuesFromPreviousPage { get; set; }
    public bool ContinuesOnNextPage { get; set; }
    public List<List<TableCell>> Rows { get; set; } = [];
}

public sealed class TableCell
{
    public string Text { get; set; } = string.Empty;
    public bool IsHeader { get; set; }
    public int ColumnIndex { get; set; }
    public int RowSpan { get; set; } = 1;
    public int ColumnSpan { get; set; } = 1;
    public string HorizontalAlignment { get; set; } = "left";
}

public sealed class ListBlock : PdfBlock
{
    public bool Ordered { get; set; }
    public List<ListItem> Items { get; set; } = [];
}

public sealed class ListItem
{
    public string Text { get; set; } = string.Empty;
    public List<PdfTextRun> Runs { get; set; } = [];
}

public sealed class PdfTextRun
{
    public string Text { get; set; } = string.Empty;
    public string FontName { get; set; } = string.Empty;
    public double FontSize { get; set; }
    public double SpaceWidth { get; set; }
    public bool Bold { get; set;}
    public bool Italic { get; set; }
    public string Color { get; set; } = "#000000";
    public double X { get; set; }
    public double Y { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
}

public sealed class PdfPathSegment
{
    public double X1 { get; init; }
    public double Y1 { get; init; }
    public double X2 { get; init; }
    public double Y2 { get; init; }
}

public sealed class PdfTextLine
{
    public List<PdfTextRun> Runs { get; init; } = [];
    public string Text { get; init; } = string.Empty;
    public double X { get; init; }
    public double Y { get; init; }
    public double Width { get; init; }
    public double Height { get; init; }
    public double AverageFontSize => Runs.Count == 0 ? 0 : Runs.Average(run => run.FontSize);
}
