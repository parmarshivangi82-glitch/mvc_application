namespace MVCapplication.Models;

public sealed class PdfHistoryItem
{
    public int Id { get; init; }

    public string FileName { get; init; } = string.Empty;
}
