using System.ComponentModel.DataAnnotations;

namespace MVCapplication.Models;

public sealed class UploadedPdf
{
    public int Id { get; set; }

    [Required, StringLength(255)]
    public string FileName { get; set; } = string.Empty;

    public string ExtractedDocumentJson { get; set; } = string.Empty;
}
