using MVCapplication.Models;

namespace MVCapplication.ViewModels;

public sealed class PdfResultViewModel
{
    public int Id { get; init; }
    public string FileName { get; init; } = string.Empty;
    public ExtractedDocument Document { get; init; } = new();
    public string PlainText { get; init; } = string.Empty;
}
