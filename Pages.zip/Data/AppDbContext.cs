using Microsoft.EntityFrameworkCore;
using MVCapplication.Models;

namespace MVCapplication.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<UploadedPdf> UploadedPdfs => Set<UploadedPdf>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<UploadedPdf>(entity =>
        {
            entity.Property(pdf => pdf.FileName).HasMaxLength(255).IsRequired();
            entity.Property(pdf => pdf.ExtractedDocumentJson)
                .HasColumnName("ExtractedText")
                .HasColumnType("nvarchar(max)")
                .IsRequired();
        });
    }
}
